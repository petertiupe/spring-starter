package de.tiupe.de.tiupe.cd;

public interface CompactDisc {
    void play();
}
